import React from "react";

const Miscellaneous = () => {
  return <div>Miscellaneous</div>;
};

export default Miscellaneous;
