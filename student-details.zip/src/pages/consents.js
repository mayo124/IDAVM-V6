import React from "react";

const Consents = () => {
  return <div>Consents</div>;
};

export default Consents;
